﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassWithPrivateFields
{
    class CarPrivateFields
    {
        // Fields
        private string _make;
        private string _model;
        private string _color;
        private int _year;
        private decimal _mileage;
        private decimal _price;

        public CarPrivateFields(string make, string model, string color, int year, decimal mileage, decimal price)
        {
            _make = make;
            _model =model;
            _color = color;
            _year = year;
            _mileage = mileage;
            _price = price;
        }

        // Make property
        public string Make { get { return _make; }}

        // Model Property
        public string Model { get { return _model; }}

        // Color Property
        public string Color { get { return _color; }}

        // Year Property
        public int Year { get { return _year; }}

        // Mileade Property
        public decimal Mileage { get { return _mileage; }}

        // Price Property
        public decimal Price { get { return _price; }}

    }
}
 